﻿"use client";

import { useEffect, useState } from "react";

async function urlBase64ToUint8Array(base64String: string) {
  const padding = "=".repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, "+").replace(/_/g, "/");
  const raw = atob(base64);
  const output = new Uint8Array(raw.length);
  for (let i = 0; i < raw.length; i++) output[i] = raw.charCodeAt(i);
  return output;
}

export default function PushRegister() {
  const [status, setStatus] = useState<string>("");

  useEffect(() => {
    (async () => {
      try {
        if (!("serviceWorker" in navigator)) return;
        if (!("PushManager" in window)) return;

        const reg = await navigator.serviceWorker.register("/sw-push.js");

        const perm = await Notification.requestPermission();
        if (perm !== "granted") {
          setStatus("Notificações desativadas");
          return;
        }

        const existing = await reg.pushManager.getSubscription();
        if (existing) {
          setStatus("Notificações ativas ✅");
          return;
        }

        const vapidPublic = process.env.NEXT_PUBLIC_VAPID_PUBLIC_KEY || "";
        if (!vapidPublic) {
          setStatus("Falta NEXT_PUBLIC_VAPID_PUBLIC_KEY");
          return;
        }

        const sub = await reg.pushManager.subscribe({
          userVisibleOnly: true,
          applicationServerKey: await urlBase64ToUint8Array(vapidPublic),
        });

        const r = await fetch("/api/push/subscribe", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          credentials: "include",
          body: JSON.stringify(sub),
        });

        if (!r.ok) {
          const t = await r.text();
          throw new Error(t || "Falha ao registrar push");
        }

        setStatus("Notificações ativas ✅");
      } catch (e: any) {
        setStatus(e?.message || "Erro ao ativar notificações");
      }
    })();
  }, []);

  if (!status) return null;
  return <div className="small" style={{ opacity: 0.85 }}>{status}</div>;
}
