"use client";

import Link from "next/link";
import { useState } from "react";

async function safeJson(res: Response) {
  try {
    const text = await res.text();
    try {
      return JSON.parse(text);
    } catch {
      return { error: text || `Erro ${res.status}` };
    }
  } catch {
    return { error: "Falha de conexão" };
  }
}

export default function SaidaCarroPage() {
  const [placa, setPlaca] = useState("");
  const [motorista, setMotorista] = useState("");
  const [destino, setDestino] = useState("");
  const [qtdPaletes, setQtdPaletes] = useState("");

  const [levaPaleteira, setLevaPaleteira] = useState(false);
  const [qtdPaleteira, setQtdPaleteira] = useState("1");

  const [levaStretch, setLevaStretch] = useState(false);
  const [exigeTubete, setExigeTubete] = useState(true);

  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState("");

  async function salvar() {
    setLoading(true);
    setMsg("");
    try {
      const r = await fetch("/api/carros/saida", {
        method: "POST",
        headers: { "Content-Type": "application/json", "Cache-Control": "no-store" },
        credentials: "include",
        body: JSON.stringify({
          placa,
          motorista,
          destino,
          qtd_paletes: qtdPaletes,
          leva_paleteira: levaPaleteira,
          qtd_paleteira: levaPaleteira ? qtdPaleteira : null,
          leva_stretch: levaStretch,
          exige_tubete_retorno: levaStretch ? exigeTubete : false,
        }),
      });

      const d = await safeJson(r);
      if (!r.ok) throw new Error(d?.error || "Falha ao salvar");

      setMsg("✅ Saída registrada!");
      setPlaca("");
      setMotorista("");
      setDestino("");
      setQtdPaletes("");
      setLevaPaleteira(false);
      setLevaStretch(false);
    } catch (e: any) {
      setMsg(e?.message || "Erro");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main style={{ padding: 16, maxWidth: 1100, margin: "0 auto" }}>
      <div style={{ display: "flex", justifyContent: "space-between", gap: 12, flexWrap: "wrap" }}>
        <div>
          <h1 style={{ margin: 0 }}>🚚 Saída do carro</h1>
          <div style={{ opacity: 0.8, marginTop: 4 }}>Registre o que saiu e o que precisa voltar.</div>
        </div>
        <Link href="/pendencias" style={{ color: "#8ab4ff" }}>Ver pendências →</Link>
      </div>

      <div style={{ display: "grid", gap: 12, marginTop: 14 }}>
        <section style={{ background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.10)", borderRadius: 14, padding: 14 }}>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))", gap: 10 }}>
            <input value={placa} onChange={(e) => setPlaca(e.target.value)} placeholder="Placa (opcional)" style={inp} />
            <input value={motorista} onChange={(e) => setMotorista(e.target.value)} placeholder="Motorista (opcional)" style={inp} />
            <input value={destino} onChange={(e) => setDestino(e.target.value)} placeholder="Destino (opcional)" style={inp} />
            <input value={qtdPaletes} onChange={(e) => setQtdPaletes(e.target.value)} placeholder="Qtd paletes" inputMode="numeric" style={inp} />
          </div>

          <div style={{ display: "grid", gap: 10, marginTop: 12 }}>
            <label style={lbl}>
              <input type="checkbox" checked={levaPaleteira} onChange={(e) => setLevaPaleteira(e.target.checked)} />
              Leva paleteira?
            </label>

            {levaPaleteira ? (
              <input value={qtdPaleteira} onChange={(e) => setQtdPaleteira(e.target.value)} placeholder="Qtd paleteiras" inputMode="numeric" style={inp} />
            ) : null}

            <label style={lbl}>
              <input type="checkbox" checked={levaStretch} onChange={(e) => setLevaStretch(e.target.checked)} />
              Leva stretch?
            </label>

            {levaStretch ? (
              <label style={lbl}>
                <input type="checkbox" checked={exigeTubete} onChange={(e) => setExigeTubete(e.target.checked)} />
                Exigir devolução do tubete no retorno
              </label>
            ) : null}
          </div>

          <div style={{ display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap", marginTop: 14 }}>
            <button onClick={salvar} disabled={loading} style={btn}>
              {loading ? "Salvando…" : "💾 Registrar saída"}
            </button>
            <Link href="/" style={{ color: "#8ab4ff" }}>⬅ Home</Link>
            {msg ? <span style={{ opacity: 0.9 }}>{msg}</span> : null}
          </div>
        </section>
      </div>
    </main>
  );
}

const inp: React.CSSProperties = {
  padding: 10,
  borderRadius: 10,
  border: "1px solid rgba(255,255,255,0.14)",
  background: "rgba(0,0,0,0.25)",
  color: "inherit",
};

const lbl: React.CSSProperties = { display: "flex", gap: 8, alignItems: "center", opacity: 0.9 };

const btn: React.CSSProperties = {
  cursor: "pointer",
  padding: "10px 14px",
  borderRadius: 12,
  border: "1px solid rgba(255,255,255,0.14)",
  background: "rgba(138,180,255,0.20)",
  color: "inherit",
};
