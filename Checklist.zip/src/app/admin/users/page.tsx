"use client";

import { useEffect, useState } from "react";

async function safeJson(res: Response) {
  try {
    const text = await res.text();
    try {
      return JSON.parse(text);
    } catch {
      return { error: text || `Erro ${res.status}` };
    }
  } catch {
    return { error: "Falha de conexão" };
  }
}

type U = {
  id: string;
  username: string;
  role: string;
  prefs: {
    turno_default: "08:00" | "13:00" | "23:00";
    notify_enabled: boolean;
    notify_checklist: boolean;
    notify_pendencias: boolean;
  };
};

export default function AdminUsersPage() {
  const [rows, setRows] = useState<U[]>([]);
  const [msg, setMsg] = useState("");
  const [loading, setLoading] = useState(true);

  async function load() {
    setLoading(true);
    setMsg("");
    try {
      const r = await fetch("/api/admin/users/list", { credentials: "include", cache: "no-store" });
      const d = await safeJson(r);
      if (!r.ok) throw new Error(d?.error || "Falha ao carregar");
      setRows(d.rows || []);
    } catch (e: any) {
      setMsg(e?.message || "Erro");
      setRows([]);
    } finally {
      setLoading(false);
    }
  }

  async function save(u: U) {
    setMsg("");
    try {
      const r = await fetch("/api/admin/users/update", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({
          user_id: u.id,
          turno_default: u.prefs.turno_default,
          notify_enabled: u.prefs.notify_enabled,
          notify_checklist: u.prefs.notify_checklist,
          notify_pendencias: u.prefs.notify_pendencias,
        }),
      });
      const d = await safeJson(r);
      if (!r.ok) throw new Error(d?.error || "Falha ao salvar");
      setMsg(`✅ Salvo: ${u.username}`);
    } catch (e: any) {
      setMsg(e?.message || "Erro");
    }
  }

  useEffect(() => {
    load();
  }, []);

  return (
    <main style={{ padding: 16, maxWidth: 1100, margin: "0 auto" }}>
      <h1 style={{ marginTop: 0 }}>Admin • Turno por usuário</h1>
      <div style={{ opacity: 0.85 }}>Defina turno padrão e quem recebe notificações.</div>

      <div style={{ display: "flex", gap: 10, marginTop: 12, alignItems: "center" }}>
        <button onClick={load} disabled={loading} style={btnSecondary}>{loading ? "…" : "🔄 Atualizar"}</button>
        {msg ? <span style={{ opacity: 0.9 }}>{msg}</span> : null}
      </div>

      <div style={{ display: "grid", gap: 10, marginTop: 14 }}>
        {rows.map((u) => (
          <div key={u.id} style={card}>
            <div style={{ display: "flex", justifyContent: "space-between", gap: 10, flexWrap: "wrap" }}>
              <div>
                <div style={{ fontSize: 16 }}><b>{u.username}</b> <span style={pill}>{u.role}</span></div>
                <div style={{ marginTop: 8, display: "flex", gap: 10, flexWrap: "wrap", alignItems: "center" }}>
                  <label style={lbl}>Turno:</label>
                  <select
                    value={u.prefs.turno_default}
                    onChange={(e) => {
                      const v = e.target.value as any;
                      setRows((prev) => prev.map((x) => x.id === u.id ? { ...x, prefs: { ...x.prefs, turno_default: v } } : x));
                    }}
                    style={inp}
                  >
                    <option value="08:00">08:00</option>
                    <option value="13:00">13:00</option>
                    <option value="23:00">23:00</option>
                  </select>

                  <label style={chk}>
                    <input
                      type="checkbox"
                      checked={u.prefs.notify_enabled}
                      onChange={(e) => setRows((prev) => prev.map((x) => x.id === u.id ? { ...x, prefs: { ...x.prefs, notify_enabled: e.target.checked } } : x))}
                    />
                    Notificações
                  </label>

                  <label style={chk}>
                    <input
                      type="checkbox"
                      checked={u.prefs.notify_checklist}
                      onChange={(e) => setRows((prev) => prev.map((x) => x.id === u.id ? { ...x, prefs: { ...x.prefs, notify_checklist: e.target.checked } } : x))}
                    />
                    Checklist
                  </label>

                  <label style={chk}>
                    <input
                      type="checkbox"
                      checked={u.prefs.notify_pendencias}
                      onChange={(e) => setRows((prev) => prev.map((x) => x.id === u.id ? { ...x, prefs: { ...x.prefs, notify_pendencias: e.target.checked } } : x))}
                    />
                    Pendências
                  </label>

                  <button onClick={() => save(u)} style={btnPrimary}>💾 Salvar</button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </main>
  );
}

const card: React.CSSProperties = {
  background: "rgba(255,255,255,0.06)",
  border: "1px solid rgba(255,255,255,0.10)",
  borderRadius: 14,
  padding: 14,
};
const inp: React.CSSProperties = {
  padding: "8px 10px",
  borderRadius: 10,
  border: "1px solid rgba(255,255,255,0.14)",
  background: "rgba(0,0,0,0.25)",
  color: "inherit",
};
const lbl: React.CSSProperties = { opacity: 0.85 };
const chk: React.CSSProperties = { display: "flex", gap: 6, alignItems: "center", opacity: 0.9 };
const pill: React.CSSProperties = { marginLeft: 8, padding: "3px 8px", borderRadius: 999, background: "rgba(255,255,255,0.10)", fontSize: 12 };
const btnPrimary: React.CSSProperties = {
  cursor: "pointer",
  padding: "8px 12px",
  borderRadius: 12,
  border: "1px solid rgba(255,255,255,0.14)",
  background: "rgba(138,180,255,0.20)",
  color: "inherit",
};
const btnSecondary: React.CSSProperties = {
  cursor: "pointer",
  padding: "8px 12px",
  borderRadius: 12,
  border: "1px solid rgba(255,255,255,0.14)",
  background: "rgba(255,255,255,0.06)",
  color: "inherit",
};
