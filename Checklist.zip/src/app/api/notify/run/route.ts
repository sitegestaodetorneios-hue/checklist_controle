﻿import { NextResponse } from "next/server";
import webpush from "web-push";
import { supabaseAdmin } from "@/lib/supabaseAdmin";

function ymd(d: Date) {
  const yyyy = d.getFullYear().toString().padStart(4, "0");
  const mm = (d.getMonth() + 1).toString().padStart(2, "0");
  const dd = d.getDate().toString().padStart(2, "0");
  return `${yyyy}-${mm}-${dd}`;
}

export async function POST(req: Request) {
  // Protege por secret (para cron chamar)
  const secret = req.headers.get("x-cron-secret") || "";
  if (!process.env.CRON_SECRET || secret !== process.env.CRON_SECRET) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const VAPID_PUBLIC = process.env.NEXT_PUBLIC_VAPID_PUBLIC_KEY || "";
  const VAPID_PRIVATE = process.env.VAPID_PRIVATE_KEY || "";
  const VAPID_SUBJECT = process.env.VAPID_SUBJECT || "mailto:suporte@seu-dominio.com";

  if (!VAPID_PUBLIC || !VAPID_PRIVATE) {
    return NextResponse.json({ error: "VAPID keys ausentes" }, { status: 500 });
  }

  webpush.setVapidDetails(VAPID_SUBJECT, VAPID_PUBLIC, VAPID_PRIVATE);

  const now = new Date();
  const today = ymd(now);

  // Carrega regras por unidade (se não tiver, usa padrão)
  const rulesQ = await supabaseAdmin
    .from("notification_rules")
    .select("unidade_id,checklist_due_time,enabled")
    .eq("enabled", true);

  if (rulesQ.error) return NextResponse.json({ error: rulesQ.error.message }, { status: 500 });

  const rules = (rulesQ.data || []) as any[];
  if (!rules.length) return NextResponse.json({ ok: true, msg: "Sem regras" });

  let sent = 0;

  for (const rule of rules) {
    const unidade_id = rule.unidade_id;

    // 1) Checklist feito hoje?
    const chkQ = await supabaseAdmin
      .from("turno_checklists")
      .select("id")
      .eq("unidade_id", unidade_id)
      .gte("created_at", `${today}T00:00:00Z`)
      .limit(1);

    if (chkQ.error) continue;

    const checklistFeito = (chkQ.data || []).length > 0;

    // 2) Pendências de retorno?
    const pendQ = await supabaseAdmin
      .from("carregamentos")
      .select("id,status,placa,motorista,created_at,leva_paleteira,leva_stretch,exige_tubete_retorno")
      .eq("unidade_id", unidade_id)
      .in("status", ["EM_ROTA", "PENDENTE_DEVOLUCAO"])
      .limit(50);

    const pendencias = pendQ.error ? [] : (pendQ.data || []);

    const needsNotifyChecklist = !checklistFeito; // (o horário fino você pode aplicar depois com due_time)
    const needsNotifyPend = pendencias.length > 0;

    if (!needsNotifyChecklist && !needsNotifyPend) continue;

    // Busca subscriptions da unidade
    const subQ = await supabaseAdmin
      .from("push_subscriptions")
      .select("endpoint,p256dh,auth")
      .eq("unidade_id", unidade_id)
      .eq("is_active", true)
      .limit(200);

    if (subQ.error) continue;

    const subs = (subQ.data || []) as any[];

    const notifications: { title: string; body: string; url: string }[] = [];

    if (needsNotifyChecklist) {
      notifications.push({
        title: "Checklist de turno pendente",
        body: "Ainda não foi feito o checklist de início de turno. Toque para abrir.",
        url: "/turno",
      });
    }

    if (needsNotifyPend) {
      notifications.push({
        title: "Pendências de retorno",
        body: `Você tem ${pendencias.length} carregamento(s) com retorno pendente. Toque para ver.`,
        url: "/pendencias",
      });
    }

    for (const n of notifications) {
      const payload = JSON.stringify(n);

      for (const s of subs) {
        try {
          await webpush.sendNotification(
            {
              endpoint: s.endpoint,
              keys: { p256dh: s.p256dh, auth: s.auth },
            },
            payload
          );
          sent++;
        } catch {
          // se falhar muito, você pode marcar is_active=false aqui
        }
      }
    }
  }

  return NextResponse.json({ ok: true, sent });
}
