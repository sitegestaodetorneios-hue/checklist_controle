import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/currentUser";
import { supabaseAdmin } from "@/lib/supabaseAdmin";

function toBool(v: any) {
  if (typeof v === "boolean") return v;
  const s = String(v ?? "").trim().toLowerCase();
  return s === "1" || s === "true" || s === "sim" || s === "yes";
}

export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Login expirado" }, { status: 401 });
  if (!user.unidade_id) return NextResponse.json({ error: "Usuário sem unidade" }, { status: 400 });

  const body = await req.json().catch(() => ({}));
  const carregamento_id = String(body?.carregamento_id || "").trim();
  if (!carregamento_id) return NextResponse.json({ error: "carregamento_id obrigatório" }, { status: 400 });

  // valida se pertence à unidade
  const cQ = await supabaseAdmin
    .from("carregamentos")
    .select("id,unidade_id,leva_paleteira,leva_stretch,exige_tubete_retorno,status")
    .eq("id", carregamento_id)
    .maybeSingle();

  if (cQ.error) return NextResponse.json({ error: cQ.error.message }, { status: 500 });
  if (!cQ.data) return NextResponse.json({ error: "Carregamento não encontrado" }, { status: 404 });
  if (String(cQ.data.unidade_id) !== String(user.unidade_id)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  const paleteira_devolvida = toBool(body?.paleteira_devolvida);
  const tubete_devolvido = toBool(body?.tubete_devolvido);
  const obs = String(body?.obs || "").trim() || null;

  // pendência: se levou paleteira, exige devolvida; se exige tubete, exige tubete_devolvido
  const pendPal = cQ.data.leva_paleteira && !paleteira_devolvida;
  const pendTub = cQ.data.exige_tubete_retorno && !tubete_devolvido;

  const ok_final = !(pendPal || pendTub);

  // upsert retorno (1:1)
  const retQ = await supabaseAdmin
    .from("carregamento_retorno")
    .upsert(
      {
        carregamento_id,
        returned_by: user.id,
        paleteira_devolvida: cQ.data.leva_paleteira ? paleteira_devolvida : null,
        tubete_devolvido: cQ.data.exige_tubete_retorno ? tubete_devolvido : null,
        obs,
        ok_final,
      },
      { onConflict: "carregamento_id" }
    );

  if (retQ.error) return NextResponse.json({ error: retQ.error.message }, { status: 500 });

  // atualiza status do carregamento
  const status = ok_final ? "FECHADO" : "PENDENTE_DEVOLUCAO";
  const upd = await supabaseAdmin.from("carregamentos").update({ status }).eq("id", carregamento_id);
  if (upd.error) return NextResponse.json({ error: upd.error.message }, { status: 500 });

  return NextResponse.json({ ok: true, ok_final, status });
}
