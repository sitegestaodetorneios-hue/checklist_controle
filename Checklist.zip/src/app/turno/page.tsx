﻿"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";

async function safeJson(res: Response) {
  try {
    const text = await res.text();
    try {
      return JSON.parse(text);
    } catch {
      return { error: text || `Erro ${res.status}` };
    }
  } catch {
    return { error: "Falha de conexão" };
  }
}

const TURNOS = ["08:00", "13:00", "23:00"] as const;

function onlyDigits(v: string) {
  return v.replace(/[^\d]/g, "");
}

function badgeStyle(active = false): React.CSSProperties {
  return {
    cursor: "pointer",
    borderRadius: 999,
    padding: "8px 12px",
    border: "1px solid rgba(255,255,255,0.14)",
    background: active ? "rgba(138,180,255,0.22)" : "rgba(255,255,255,0.06)",
    color: "inherit",
    fontWeight: active ? 700 : 500,
  };
}

export default function TurnoPage() {
  const [turno, setTurno] = useState<(typeof TURNOS)[number]>("08:00");

  const [coletoresTotal, setColetoresTotal] = useState<string>("");
  const [coletoresOk, setColetoresOk] = useState<string>("");

  const [paleteirasTotal, setPaleteirasTotal] = useState<string>("");
  const [paleteirasOk, setPaleteirasOk] = useState<string>("");

  const [obsColetores, setObsColetores] = useState<string>("");
  const [obsPaleteiras, setObsPaleteiras] = useState<string>("");

  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState<string>("");

  // ✅ carrega turno default do usuário (admin configurou)
  useEffect(() => {
    (async () => {
      try {
        const r = await fetch("/api/auth/me", { credentials: "include", cache: "no-store" });
        const d = await safeJson(r);
        if (r.ok && d?.prefs?.turno_default && TURNOS.includes(d.prefs.turno_default)) {
          setTurno(d.prefs.turno_default);
        }
      } catch {}
    })();
  }, []);

  const warn = useMemo(() => {
    const ct = Number(coletoresTotal || 0);
    const co = Number(coletoresOk || 0);
    const pt = Number(paleteirasTotal || 0);
    const po = Number(paleteirasOk || 0);

    const alerts: string[] = [];
    if (ct && co && co > ct) alerts.push("Coletores OK maior que o total.");
    if (pt && po && po > pt) alerts.push("Paleteiras OK maior que o total.");
    return alerts;
  }, [coletoresTotal, coletoresOk, paleteirasTotal, paleteirasOk]);

  const resumo = useMemo(() => {
    const ct = Number(coletoresTotal || 0);
    const co = Number(coletoresOk || 0);
    const pt = Number(paleteirasTotal || 0);
    const po = Number(paleteirasOk || 0);

    const okColetores = ct ? `${co || 0}/${ct}` : "—";
    const okPaleteiras = pt ? `${po || 0}/${pt}` : "—";

    return { okColetores, okPaleteiras };
  }, [coletoresTotal, coletoresOk, paleteirasTotal, paleteirasOk]);

  async function salvar() {
    setLoading(true);
    setMsg("");

    try {
      const r = await fetch("/api/turno/create", {
        method: "POST",
        headers: { "Content-Type": "application/json", "Cache-Control": "no-store" },
        credentials: "include",
        cache: "no-store",
        body: JSON.stringify({
          turno_label: turno,
          coletores_total: coletoresTotal,
          coletores_ok: coletoresOk,
          coletores_obs: obsColetores,
          paleteiras_total: paleteirasTotal,
          paleteiras_ok: paleteirasOk,
          paleteiras_obs: obsPaleteiras,
        }),
      });

      const d = await safeJson(r);
      if (!r.ok) throw new Error(d?.error || "Falha ao salvar");

      setMsg("✅ Checklist salvo com sucesso!");
      // mantém números, limpa observações (fluxo rápido)
      setObsColetores("");
      setObsPaleteiras("");
    } catch (e: any) {
      setMsg(e?.message || "Erro");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main style={{ padding: 16, maxWidth: 1100, margin: "0 auto" }}>
      {/* Top bar */}
      <div
        style={{
          display: "flex",
          alignItems: "baseline",
          justifyContent: "space-between",
          gap: 12,
          flexWrap: "wrap",
        }}
      >
        <div>
          <h1 style={{ margin: 0 }}>✅ Checklist de Turno</h1>
          <div style={{ opacity: 0.8, marginTop: 4 }}>
            Preencha rápido. O sistema usa isso para auditoria e notificações.
          </div>
        </div>

        <div style={{ display: "flex", gap: 10, flexWrap: "wrap", alignItems: "center" }}>
          <Link href="/" style={{ color: "#8ab4ff" }}>⬅ Home</Link>
          <Link href="/pendencias" style={{ color: "#8ab4ff" }}>Pendências →</Link>
        </div>
      </div>

      {/* Resumo premium */}
      <div style={{ display: "grid", gap: 12, marginTop: 14 }}>
        <section style={card}>
          <div style={{ display: "flex", justifyContent: "space-between", gap: 10, flexWrap: "wrap" }}>
            <div>
              <div style={{ fontSize: 14, opacity: 0.85 }}>Turno selecionado</div>
              <div style={{ marginTop: 6, display: "flex", gap: 8, flexWrap: "wrap" }}>
                {TURNOS.map((t) => (
                  <button key={t} onClick={() => setTurno(t)} style={badgeStyle(turno === t)}>
                    {t}
                  </button>
                ))}
              </div>
            </div>

            <div style={{ textAlign: "right" }}>
              <div style={{ fontSize: 14, opacity: 0.85 }}>Resumo</div>
              <div style={{ marginTop: 6, display: "flex", gap: 8, flexWrap: "wrap", justifyContent: "flex-end" }}>
                <span style={pill}>📱 Coletores: {resumo.okColetores}</span>
                <span style={pill}>🛒 Paleteiras: {resumo.okPaleteiras}</span>
              </div>
            </div>
          </div>
        </section>

        {/* Inputs */}
        <section style={card}>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))", gap: 12 }}>
            {/* Coletores */}
            <div>
              <h2 style={{ margin: 0, fontSize: 16 }}>📱 Coletores</h2>
              <div style={{ display: "grid", gap: 8, marginTop: 10 }}>
                <div style={grid2}>
                  <input
                    value={coletoresTotal}
                    onChange={(e) => setColetoresTotal(onlyDigits(e.target.value))}
                    placeholder="Total"
                    inputMode="numeric"
                    style={inp}
                  />
                  <input
                    value={coletoresOk}
                    onChange={(e) => setColetoresOk(onlyDigits(e.target.value))}
                    placeholder="OK"
                    inputMode="numeric"
                    style={inp}
                  />
                </div>

                <textarea
                  value={obsColetores}
                  onChange={(e) => setObsColetores(e.target.value)}
                  placeholder="Observações (ex: coletor 12 com tela quebrada)"
                  rows={3}
                  style={txt}
                />
              </div>
            </div>

            {/* Paleteiras */}
            <div>
              <h2 style={{ margin: 0, fontSize: 16 }}>🛒 Paleteiras</h2>
              <div style={{ display: "grid", gap: 8, marginTop: 10 }}>
                <div style={grid2}>
                  <input
                    value={paleteirasTotal}
                    onChange={(e) => setPaleteirasTotal(onlyDigits(e.target.value))}
                    placeholder="Total"
                    inputMode="numeric"
                    style={inp}
                  />
                  <input
                    value={paleteirasOk}
                    onChange={(e) => setPaleteirasOk(onlyDigits(e.target.value))}
                    placeholder="OK"
                    inputMode="numeric"
                    style={inp}
                  />
                </div>

                <textarea
                  value={obsPaleteiras}
                  onChange={(e) => setObsPaleteiras(e.target.value)}
                  placeholder="Observações (ex: paleteira 3 com vazamento)"
                  rows={3}
                  style={txt}
                />
              </div>
            </div>
          </div>

          {warn.length ? (
            <div style={warnBox}>
              <b>Atenção:</b> {warn.join(" ")}
            </div>
          ) : null}
        </section>

        {/* Ações */}
        <section style={{ display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap" }}>
          <button onClick={salvar} disabled={loading} style={btnPrimary}>
            {loading ? "Salvando…" : "💾 Salvar checklist"}
          </button>

          <button
            type="button"
            disabled={loading}
            onClick={() => {
              setColetoresTotal("");
              setColetoresOk("");
              setPaleteirasTotal("");
              setPaleteirasOk("");
              setObsColetores("");
              setObsPaleteiras("");
              setMsg("");
            }}
            style={btnSecondary}
          >
            Limpar
          </button>

          {msg ? <span style={{ opacity: 0.92 }}>{msg}</span> : null}
        </section>
      </div>
    </main>
  );
}

/* ===== estilos premium (consistentes com seu tema escuro) ===== */
const card: React.CSSProperties = {
  background: "rgba(255,255,255,0.06)",
  border: "1px solid rgba(255,255,255,0.10)",
  borderRadius: 14,
  padding: 14,
};

const pill: React.CSSProperties = {
  padding: "6px 10px",
  borderRadius: 999,
  background: "rgba(255,255,255,0.08)",
  fontSize: 13,
};

const grid2: React.CSSProperties = {
  display: "grid",
  gridTemplateColumns: "1fr 1fr",
  gap: 8,
};

const inp: React.CSSProperties = {
  padding: 10,
  borderRadius: 10,
  border: "1px solid rgba(255,255,255,0.14)",
  background: "rgba(0,0,0,0.25)",
  color: "inherit",
};

const txt: React.CSSProperties = {
  padding: 10,
  borderRadius: 10,
  border: "1px solid rgba(255,255,255,0.14)",
  background: "rgba(0,0,0,0.25)",
  color: "inherit",
};

const warnBox: React.CSSProperties = {
  marginTop: 12,
  padding: 10,
  borderRadius: 10,
  background: "rgba(255, 193, 7, 0.12)",
  border: "1px solid rgba(255, 193, 7, 0.25)",
};

const btnPrimary: React.CSSProperties = {
  cursor: "pointer",
  padding: "10px 14px",
  borderRadius: 12,
  border: "1px solid rgba(255,255,255,0.14)",
  background: "rgba(138,180,255,0.20)",
  color: "inherit",
};

const btnSecondary: React.CSSProperties = {
  cursor: "pointer",
  padding: "10px 14px",
  borderRadius: 12,
  border: "1px solid rgba(255,255,255,0.14)",
  background: "rgba(255,255,255,0.06)",
  color: "inherit",
};
