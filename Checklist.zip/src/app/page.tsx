﻿import Link from "next/link";
import PushRegister from "./components/PushRegister";

export default function Home() {
  return (
    <main style={{ padding: 16, maxWidth: 1100, margin: "0 auto" }}>
      <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", gap: 12, flexWrap: "wrap" }}>
        <div>
          <h1 style={{ margin: 0 }}>Checklist Turno</h1>
          <div style={{ opacity: 0.8, marginTop: 4 }}>PWA premium • turno • saída • retorno • pendências</div>
        </div>
        <div style={{ minWidth: 220 }}>
          <PushRegister />
        </div>
      </div>

      <div style={{ display: "grid", gap: 12, marginTop: 14 }}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))", gap: 12 }}>
          <Link
            href="/turno"
            style={{
              textDecoration: "none",
              background: "rgba(255,255,255,0.06)",
              border: "1px solid rgba(255,255,255,0.10)",
              borderRadius: 14,
              padding: 14,
              color: "inherit",
              display: "block",
            }}
          >
            <div style={{ fontSize: 14, opacity: 0.8 }}>Início de turno</div>
            <div style={{ fontSize: 20, marginTop: 6 }}>✅ Fazer checklist</div>
            <div style={{ marginTop: 8, opacity: 0.75, fontSize: 13 }}>
              Coletores • paleteiras • observações
            </div>
          </Link>

          <Link
            href="/pendencias"
            style={{
              textDecoration: "none",
              background: "rgba(255,255,255,0.06)",
              border: "1px solid rgba(255,255,255,0.10)",
              borderRadius: 14,
              padding: 14,
              color: "inherit",
              display: "block",
            }}
          >
            <div style={{ fontSize: 14, opacity: 0.8 }}>Retorno / devolução</div>
            <div style={{ fontSize: 20, marginTop: 6 }}>🚨 Ver pendências</div>
            <div style={{ marginTop: 8, opacity: 0.75, fontSize: 13 }}>
              Paleteira • tubete do stretch • pendente de retorno
            </div>
          </Link>
        </div>

        <div
          style={{
            background: "rgba(255,255,255,0.04)",
            border: "1px solid rgba(255,255,255,0.08)",
            borderRadius: 14,
            padding: 14,
          }}
        >
          <div style={{ fontSize: 14, opacity: 0.85 }}>Turnos padrão</div>
          <div style={{ marginTop: 8, display: "flex", gap: 8, flexWrap: "wrap" }}>
            <span style={{ padding: "6px 10px", borderRadius: 999, background: "rgba(255,255,255,0.08)" }}>08:00</span>
            <span style={{ padding: "6px 10px", borderRadius: 999, background: "rgba(255,255,255,0.08)" }}>13:00</span>
            <span style={{ padding: "6px 10px", borderRadius: 999, background: "rgba(255,255,255,0.08)" }}>23:00</span>
            <span style={{ padding: "6px 10px", borderRadius: 999, background: "rgba(255,255,255,0.08)", opacity: 0.85 }}>
              Configurável no admin
            </span>
          </div>
        </div>
      </div>
    </main>
  );
}
